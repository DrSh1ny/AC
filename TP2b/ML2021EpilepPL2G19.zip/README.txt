insert patient datasets inside folder dataset/
